# All Star Flooring — Cloudflare Pages site

Static HTML/CSS/JS. No build step. `index.html` must be at the project root Cloudflare builds from.

## Preview locally

```bash
python3 -m http.server 8787
```

Open http://localhost:8787

## Why `npx wrangler deploy` failed

That command deploys a **Worker**. This site is static files. Cloudflare then looks for a Worker entry or an `[assets]` folder and reports:

`Could not detect a directory containing static files`

Fix in the dashboard:

1. Open the project → **Settings → Builds & deployments**
2. **Build command:** delete `npx wrangler deploy`. Leave it blank.
3. **Build output directory:** `.`
4. **Root directory:** the folder that contains `index.html` (if the repo has a parent folder, set root to `allstar-site`)
5. Retry the deployment

## CLI (from this folder)

```bash
npx wrangler login
npx wrangler pages deploy . --project-name allstar-flooring
```

## After it is live

- Replace Unsplash photos with job photos
- Hook the quote form to Formspree, Basin, or a Worker
- Swap the placeholder email and Bothell copy
