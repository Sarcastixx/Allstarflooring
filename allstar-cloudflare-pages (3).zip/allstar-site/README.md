# All Star Flooring — Cloudflare site

Static site. HTML lives in `public/`. Wrangler 4 deploys it with `npx wrangler deploy`.

## Fix for the error you hit

    Could not detect a directory containing static files
    Executing user deploy command: npx wrangler deploy

Wrangler 4 looks for `[assets]` in wrangler.toml. If `pages_build_output_dir` is also set, it treats the project as classic Pages and skips `[assets]`.

## Dashboard settings

Workers & Pages → project → Settings → Build

- Root directory: the folder that contains wrangler.toml
- Build command: empty
- Deploy command: npx wrangler deploy

## Local preview

    python3 -m http.server 8787 --directory public
