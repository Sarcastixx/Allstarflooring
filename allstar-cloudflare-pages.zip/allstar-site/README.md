# All Star Flooring — Cloudflare Pages site

Static HTML/CSS/JS recreation of the cream-and-oak landing page. No build step.

```
allstar-site/
  index.html          Home (matches the reference layout)
  flooring.html
  services.html
  portfolio.html
  about.html
  contact.html
  css/styles.css
  js/main.js
  wrangler.toml
  _headers
```

## Preview locally

```bash
cd allstar-site
python3 -m http.server 8787
```

Open http://localhost:8787

## Deploy to Cloudflare Pages

### Option A — Dashboard (easiest)

1. Push this folder to a GitHub repo.
2. In Cloudflare: **Workers & Pages → Create → Pages → Import a Git repository**.
3. Settings:
   - Framework preset: **None**
   - Build command: *(leave empty)*
   - Build output directory: `/`
4. Deploy. You get `https://<project>.pages.dev`.
5. Add a custom domain under the project’s **Custom domains** tab.

### Option B — Wrangler CLI

```bash
npm install -g wrangler
npx wrangler login
npx wrangler pages deploy . --project-name allstar-flooring
```

## After you deploy

- Replace Unsplash photos with your project photography.
- Point the quote form at [Formspree](https://formspree.io), Basin, or a Cloudflare Worker + Turnstile.
- Swap `hello@allstarfloors.com` and the Bothell copy for your real details.
- The LS monogram is an inline SVG — drop in your real logo file if you have one.
